const express = require('express');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const CryptoJS = require('crypto-js');
const cron = require('node-cron');
const sqlite3 = require('sqlite3').verbose();
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'feathernotes_secret_key';
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'feather_encryption_key';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Database setup
const db = new sqlite3.Database('./feathernotes.db');

// Initialize database tables
db.serialize(() => {
    // Users table
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        theme TEXT DEFAULT 'light',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Notes table
    db.run(`CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        is_encrypted INTEGER DEFAULT 0,
        tags TEXT,
        color TEXT DEFAULT '#ffffff',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )`);

    // Reminders table
    db.run(`CREATE TABLE IF NOT EXISTS reminders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        note_id INTEGER,
        reminder_time DATETIME NOT NULL,
        message TEXT NOT NULL,
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id),
        FOREIGN KEY (note_id) REFERENCES notes (id)
    )`);
});

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
        return res.status(401).json({ error: 'Access denied. No token provided.' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        res.status(400).json({ error: 'Invalid token.' });
    }
};

// Encryption/Decryption functions
const encryptText = (text) => {
    return CryptoJS.AES.encrypt(text, ENCRYPTION_KEY).toString();
};

const decryptText = (encryptedText) => {
    const bytes = CryptoJS.AES.decrypt(encryptedText, ENCRYPTION_KEY);
    return bytes.toString(CryptoJS.enc.Utf8);
};

// Routes

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        message: 'FeatherNotes server is running',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// Authentication Routes
app.post('/api/register', async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        
        db.run(
            'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
            [username, email, hashedPassword],
            function(err) {
                if (err) {
                    if (err.message.includes('UNIQUE constraint failed')) {
                        return res.status(400).json({ error: 'Username or email already exists' });
                    }
                    return res.status(500).json({ error: 'Database error' });
                }
                
                const token = jwt.sign({ userId: this.lastID, username }, JWT_SECRET);
                res.json({
                    message: 'User registered successfully',
                    token,
                    user: { id: this.lastID, username, email }
                });
            }
        );
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

app.post('/api/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
    }

    db.get(
        'SELECT * FROM users WHERE email = ?',
        [email],
        async (err, user) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            if (!user || !(await bcrypt.compare(password, user.password))) {
                return res.status(401).json({ error: 'Invalid credentials' });
            }

            const token = jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET);
            res.json({
                message: 'Login successful',
                token,
                user: { id: user.id, username: user.username, email: user.email, theme: user.theme }
            });
        }
    );
});

// Notes Routes
app.get('/api/notes', verifyToken, (req, res) => {
    db.all(
        'SELECT * FROM notes WHERE user_id = ? ORDER BY updated_at DESC',
        [req.user.userId],
        (err, notes) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            // Decrypt encrypted notes
            const decryptedNotes = notes.map(note => {
                if (note.is_encrypted) {
                    try {
                        note.content = decryptText(note.content);
                        note.title = decryptText(note.title);
                    } catch (error) {
                        console.error('Decryption error:', error);
                    }
                }
                return note;
            });

            res.json(decryptedNotes);
        }
    );
});

app.post('/api/notes', verifyToken, (req, res) => {
    const { title, content, tags, color, isEncrypted } = req.body;

    if (!title || !content) {
        return res.status(400).json({ error: 'Title and content are required' });
    }

    let finalTitle = title;
    let finalContent = content;

    // Encrypt if requested
    if (isEncrypted) {
        finalTitle = encryptText(title);
        finalContent = encryptText(content);
    }

    db.run(
        'INSERT INTO notes (user_id, title, content, is_encrypted, tags, color) VALUES (?, ?, ?, ?, ?, ?)',
        [req.user.userId, finalTitle, finalContent, isEncrypted ? 1 : 0, tags, color || '#ffffff'],
        function(err) {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            res.json({
                message: 'Note created successfully',
                noteId: this.lastID
            });
        }
    );
});

app.put('/api/notes/:id', verifyToken, (req, res) => {
    const { title, content, tags, color, isEncrypted } = req.body;
    const noteId = req.params.id;

    let finalTitle = title;
    let finalContent = content;

    if (isEncrypted) {
        finalTitle = encryptText(title);
        finalContent = encryptText(content);
    }

    db.run(
        'UPDATE notes SET title = ?, content = ?, is_encrypted = ?, tags = ?, color = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?',
        [finalTitle, finalContent, isEncrypted ? 1 : 0, tags, color, noteId, req.user.userId],
        function(err) {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            if (this.changes === 0) {
                return res.status(404).json({ error: 'Note not found' });
            }

            res.json({ message: 'Note updated successfully' });
        }
    );
});

app.delete('/api/notes/:id', verifyToken, (req, res) => {
    const noteId = req.params.id;

    db.run(
        'DELETE FROM notes WHERE id = ? AND user_id = ?',
        [noteId, req.user.userId],
        function(err) {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            if (this.changes === 0) {
                return res.status(404).json({ error: 'Note not found' });
            }

            res.json({ message: 'Note deleted successfully' });
        }
    );
});

// Theme Routes
app.put('/api/user/theme', verifyToken, (req, res) => {
    const { theme } = req.body;

    if (!['light', 'dark'].includes(theme)) {
        return res.status(400).json({ error: 'Invalid theme. Must be light or dark' });
    }

    db.run(
        'UPDATE users SET theme = ? WHERE id = ?',
        [theme, req.user.userId],
        function(err) {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            res.json({ message: 'Theme updated successfully' });
        }
    );
});

// Reminders Routes
app.post('/api/reminders', verifyToken, (req, res) => {
    const { noteId, reminderTime, message } = req.body;

    if (!noteId || !reminderTime || !message) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    db.run(
        'INSERT INTO reminders (user_id, note_id, reminder_time, message) VALUES (?, ?, ?, ?)',
        [req.user.userId, noteId, reminderTime, message],
        function(err) {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            res.json({
                message: 'Reminder set successfully',
                reminderId: this.lastID
            });
        }
    );
});

app.get('/api/reminders', verifyToken, (req, res) => {
    db.all(
        `SELECT r.*, n.title as note_title 
         FROM reminders r 
         JOIN notes n ON r.note_id = n.id 
         WHERE r.user_id = ? AND r.is_active = 1 
         ORDER BY r.reminder_time ASC`,
        [req.user.userId],
        (err, reminders) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            res.json(reminders);
        }
    );
});

// AI Assistant Route (placeholder for AI integration)
app.post('/api/ai/assist', verifyToken, (req, res) => {
    const { prompt, context } = req.body;

    // This is a placeholder for AI integration
    // You can integrate with OpenAI API or other AI services
    
    // Simple response for now
    const suggestions = [
        "Consider organizing your thoughts with bullet points",
        "Add relevant tags to make your notes searchable",
        "Use headings to structure your content better",
        "Include dates and references for better context"
    ];

    res.json({
        suggestions: suggestions,
        enhancedText: `Enhanced: ${context || prompt}`
    });
});

// Reminder cron job (checks every minute)
cron.schedule('* * * * *', () => {
    const now = new Date().toISOString();
    
    db.all(
        'SELECT * FROM reminders WHERE reminder_time <= ? AND is_active = 1',
        [now],
        (err, reminders) => {
            if (err) return;

            reminders.forEach(reminder => {
                // In a real app, you'd send notifications here
                console.log(`Reminder: ${reminder.message}`);
                
                // Deactivate the reminder
                db.run(
                    'UPDATE reminders SET is_active = 0 WHERE id = ?',
                    [reminder.id]
                );
            });
        }
    );
});

// Serve frontend
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`FeatherNotes server running on port ${PORT}`);
});