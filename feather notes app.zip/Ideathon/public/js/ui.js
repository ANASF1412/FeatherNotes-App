// UI Management Module for FeatherNotes

class UIManager {
    constructor() {
        this.initializeEventListeners();
        this.setupThemeToggle();
        this.setupUserMenu();
        this.setupModals();
    }

    initializeEventListeners() {
        // Theme toggle
        document.getElementById('theme-toggle')?.addEventListener('click', () => this.toggleTheme());
        
        // User menu
        document.getElementById('user-menu-btn')?.addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleUserMenu();
        });
        
        // Close user menu when clicking outside
        document.addEventListener('click', () => {
            this.closeUserMenu();
        });
        
        // Modal close buttons
        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                if (modal) {
                    this.closeModal(modal.id);
                }
            });
        });
        
        // Settings button
        document.getElementById('settings-btn')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.showSettings();
        });
    }

    setupThemeToggle() {
        // Initialize theme from user preference or system preference
        const savedTheme = window.authManager?.user?.theme;
        const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        const initialTheme = savedTheme || systemTheme;
        
        document.documentElement.setAttribute('data-theme', initialTheme);
        this.updateThemeToggleIcon(initialTheme);
        
        // Listen for system theme changes
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            if (!window.authManager?.user?.theme) {
                const newTheme = e.matches ? 'dark' : 'light';
                document.documentElement.setAttribute('data-theme', newTheme);
                this.updateThemeToggleIcon(newTheme);
            }
        });
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        this.updateThemeToggleIcon(newTheme);
        
        // Save theme preference if user is authenticated
        if (window.authManager?.isAuthenticated()) {
            window.authManager.updateUserTheme(newTheme);
        } else {
            localStorage.setItem('feather_theme', newTheme);
        }
        
        // Add smooth transition effect
        document.body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
        setTimeout(() => {
            document.body.style.transition = '';
        }, 300);
    }

    updateThemeToggleIcon(theme) {
        const themeToggle = document.getElementById('theme-toggle');
        const icon = themeToggle?.querySelector('i');
        
        if (icon) {
            if (theme === 'dark') {
                icon.className = 'fas fa-sun';
                themeToggle.title = 'Switch to Light Theme';
            } else {
                icon.className = 'fas fa-moon';
                themeToggle.title = 'Switch to Dark Theme';
            }
        }
    }

    setupUserMenu() {
        const userMenu = document.getElementById('user-menu-btn');
        const dropdown = document.getElementById('user-dropdown');
        
        if (userMenu && dropdown) {
            userMenu.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });
        }
    }

    toggleUserMenu() {
        const dropdown = document.getElementById('user-dropdown');
        if (dropdown) {
            dropdown.classList.toggle('show');
        }
    }

    closeUserMenu() {
        const dropdown = document.getElementById('user-dropdown');
        if (dropdown) {
            dropdown.classList.remove('show');
        }
    }

    setupModals() {
        // Close modals when clicking outside
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal(modal.id);
                }
            });
        });
        
        // Close modals with Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const openModal = document.querySelector('.modal:not(.hidden)');
                if (openModal && openModal.id !== 'note-editor-modal') {
                    this.closeModal(openModal.id);
                }
            }
        });
    }

    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
            modal.classList.add('fade-in');
            
            // Focus on first input if available
            const firstInput = modal.querySelector('input, textarea');
            if (firstInput) {
                setTimeout(() => firstInput.focus(), 100);
            }
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('hidden');
            modal.classList.remove('fade-in');
        }
    }

    showSettings() {
        // Create a simple settings modal
        const settingsHtml = `
            <div id="settings-modal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><i class="fas fa-cog"></i> Settings</h3>
                        <button class="close-modal" onclick="uiManager.closeModal('settings-modal')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="settings-section">
                            <h4>Appearance</h4>
                            <div class="setting-item">
                                <label>Theme</label>
                                <div class="theme-options">
                                    <button class="btn btn-secondary" onclick="uiManager.setTheme('light')">
                                        <i class="fas fa-sun"></i> Light
                                    </button>
                                    <button class="btn btn-secondary" onclick="uiManager.setTheme('dark')">
                                        <i class="fas fa-moon"></i> Dark
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-section">
                            <h4>Data</h4>
                            <div class="setting-item">
                                <button class="btn btn-secondary" onclick="uiManager.exportNotes()">
                                    <i class="fas fa-download"></i> Export Notes
                                </button>
                                <button class="btn btn-secondary" onclick="uiManager.importNotes()">
                                    <i class="fas fa-upload"></i> Import Notes
                                </button>
                            </div>
                        </div>
                        
                        <div class="settings-section">
                            <h4>About</h4>
                            <p>FeatherNotes v1.0.0</p>
                            <p>Your intelligent note-taking companion with AI assistance and encryption.</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Remove existing settings modal if any
        const existingModal = document.getElementById('settings-modal');
        if (existingModal) {
            existingModal.remove();
        }
        
        // Add new settings modal
        document.body.insertAdjacentHTML('beforeend', settingsHtml);
        this.showModal('settings-modal');
    }

    setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        this.updateThemeToggleIcon(theme);
        
        if (window.authManager?.isAuthenticated()) {
            window.authManager.updateUserTheme(theme);
        }
        
        this.closeModal('settings-modal');
    }

    async exportNotes() {
        if (!window.notesManager?.notes?.length) {
            showNotification('No notes to export', 'warning');
            return;
        }
        
        try {
            const notesToExport = window.notesManager.notes.map(note => ({
                title: note.title,
                content: note.content,
                tags: note.tags,
                color: note.color,
                created_at: note.created_at,
                updated_at: note.updated_at,
                is_encrypted: note.is_encrypted
            }));
            
            const dataStr = JSON.stringify(notesToExport, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            
            const url = URL.createObjectURL(dataBlob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `feathernotes-export-${new Date().toISOString().split('T')[0]}.json`;
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            URL.revokeObjectURL(url);
            showNotification('Notes exported successfully!', 'success');
        } catch (error) {
            console.error('Export error:', error);
            showNotification('Failed to export notes', 'error');
        }
    }

    importNotes() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            try {
                const text = await file.text();
                const notes = JSON.parse(text);
                
                if (!Array.isArray(notes)) {
                    throw new Error('Invalid file format');
                }
                
                // Import notes one by one
                let importedCount = 0;
                for (const note of notes) {
                    try {
                        const response = await window.authManager.makeAuthenticatedRequest('/api/notes', {
                            method: 'POST',
                            body: JSON.stringify({
                                title: note.title + ' (Imported)',
                                content: note.content,
                                tags: note.tags,
                                color: note.color,
                                isEncrypted: note.is_encrypted || false
                            })
                        });
                        
                        if (response.ok) {
                            importedCount++;
                        }
                    } catch (error) {
                        console.error('Error importing note:', error);
                    }
                }
                
                if (importedCount > 0) {
                    showNotification(`Successfully imported ${importedCount} notes!`, 'success');
                    window.notesManager.loadNotes();
                } else {
                    showNotification('No notes were imported', 'warning');
                }
                
            } catch (error) {
                console.error('Import error:', error);
                showNotification('Failed to import notes. Please check the file format.', 'error');
            }
        };
        
        input.click();
    }

    // Responsive layout adjustments
    handleResize() {
        const sidebar = document.querySelector('.sidebar');
        const notesContainer = document.querySelector('.notes-container');
        
        if (window.innerWidth <= 768) {
            // Mobile layout adjustments
            if (sidebar) {
                sidebar.style.display = 'none';
            }
            if (notesContainer) {
                notesContainer.style.marginLeft = '0';
            }
        } else {
            // Desktop layout
            if (sidebar) {
                sidebar.style.display = 'block';
            }
        }
    }

    // Initialize responsive behavior
    initializeResponsive() {
        this.handleResize();
        window.addEventListener('resize', () => this.handleResize());
    }
}

// Notification system
function showNotification(message, type = 'info', duration = 4000) {
    const container = document.getElementById('notifications');
    if (!container) return;
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    const icon = getNotificationIcon(type);
    notification.innerHTML = `
        <i class="${icon}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(notification);
    
    // Auto remove after duration
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOutRight 0.3s ease forwards';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    }, duration);
    
    // Click to dismiss
    notification.addEventListener('click', () => {
        notification.remove();
    });
}

function getNotificationIcon(type) {
    switch (type) {
        case 'success': return 'fas fa-check-circle';
        case 'error': return 'fas fa-exclamation-circle';
        case 'warning': return 'fas fa-exclamation-triangle';
        case 'info': 
        default: return 'fas fa-info-circle';
    }
}

// Global function to close modals
function closeModal(modalId) {
    window.uiManager?.closeModal(modalId);
}

// Add slideOutRight animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .settings-section {
        margin-bottom: 2rem;
    }
    
    .settings-section h4 {
        margin-bottom: 1rem;
        color: var(--text-primary);
        font-size: 1.1rem;
    }
    
    .setting-item {
        margin-bottom: 1rem;
    }
    
    .setting-item label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 500;
    }
    
    .theme-options {
        display: flex;
        gap: 0.5rem;
    }
    
    .theme-options button {
        flex: 1;
    }
`;
document.head.appendChild(style);

// Initialize UI manager
window.uiManager = new UIManager();