// Reminders Management Module for FeatherNotes

class RemindersManager {
    constructor() {
        this.reminders = [];
        this.currentNoteId = null;
        this.apiUrl = '/api';
        this.notificationPermission = 'default';
        this.initializeEventListeners();
        this.requestNotificationPermission();
        this.startReminderCheck();
    }

    initializeEventListeners() {
        // Reminders modal
        document.getElementById('reminders-btn')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.showRemindersModal();
        });
        
        // Set reminder button in note editor
        document.getElementById('set-reminder-btn')?.addEventListener('click', () => {
            this.showSetReminderModal();
        });
        
        // Reminder form submission
        document.getElementById('reminder-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.createReminder();
        });
        
        // Close modals
        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                if (modal) {
                    modal.classList.add('hidden');
                }
            });
        });
    }

    async requestNotificationPermission() {
        if ('Notification' in window) {
            const permission = await Notification.requestPermission();
            this.notificationPermission = permission;
            
            if (permission === 'granted') {
                console.log('Notification permission granted');
            } else if (permission === 'denied') {
                console.log('Notification permission denied');
                showNotification('Enable notifications to receive reminders', 'warning');
            }
        }
    }

    async loadReminders() {
        try {
            const response = await window.authManager.makeAuthenticatedRequest(`${this.apiUrl}/reminders`);
            
            if (response.ok) {
                this.reminders = await response.json();
                this.renderReminders();
            } else {
                console.error('Failed to load reminders');
            }
        } catch (error) {
            console.error('Load reminders error:', error);
        }
    }

    renderReminders() {
        const remindersList = document.getElementById('reminders-list');
        if (!remindersList) return;

        if (this.reminders.length === 0) {
            remindersList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-bell-slash"></i>
                    <h4>No reminders set</h4>
                    <p>Create a reminder to never forget important notes!</p>
                </div>
            `;
            return;
        }

        // Sort reminders by time (upcoming first)
        const sortedReminders = [...this.reminders].sort((a, b) => 
            new Date(a.reminder_time) - new Date(b.reminder_time)
        );

        remindersList.innerHTML = sortedReminders.map(reminder => 
            this.createReminderCard(reminder)
        ).join('');
    }

    createReminderCard(reminder) {
        const reminderDate = new Date(reminder.reminder_time);
        const now = new Date();
        const isPast = reminderDate < now;
        const timeUntil = this.getTimeUntilReminder(reminderDate);
        
        return `
            <div class="reminder-item ${isPast ? 'past' : ''}">
                <div class="reminder-header">
                    <div class="reminder-time">
                        <i class="fas fa-clock"></i>
                        ${this.formatReminderTime(reminderDate)}
                    </div>
                    <div class="reminder-actions">
                        <button onclick="remindersManager.deleteReminder(${reminder.id})" 
                                class="btn btn-icon" title="Delete Reminder">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="reminder-message">
                    ${this.escapeHtml(reminder.message)}
                </div>
                <div class="reminder-note">
                    <i class="fas fa-sticky-note"></i>
                    Note: ${this.escapeHtml(reminder.note_title)}
                </div>
                ${!isPast ? `<div class="reminder-countdown">${timeUntil}</div>` : ''}
            </div>
        `;
    }

    showRemindersModal() {
        this.loadReminders();
        document.getElementById('reminders-modal').classList.remove('hidden');
    }

    showSetReminderModal() {
        // Get current note ID if editing a note
        this.currentNoteId = window.notesManager?.currentNote?.id || null;
        
        if (!this.currentNoteId) {
            showNotification('Please save the note first before setting a reminder', 'warning');
            return;
        }
        
        // Set minimum datetime to current time
        const now = new Date();
        const minDateTime = new Date(now.getTime() - now.getTimezoneOffset() * 60000)
            .toISOString().slice(0, 16);
        document.getElementById('reminder-datetime').min = minDateTime;
        
        // Pre-populate with a default time (1 hour from now)
        const defaultTime = new Date(now.getTime() + 60 * 60 * 1000 - now.getTimezoneOffset() * 60000)
            .toISOString().slice(0, 16);
        document.getElementById('reminder-datetime').value = defaultTime;
        
        // Pre-populate message with note title
        const noteTitle = window.notesManager?.currentNote?.title || 'Untitled Note';
        document.getElementById('reminder-message').value = `Review: ${noteTitle}`;
        
        showNotification('💡 Tip: Set reminders to never forget important notes!', 'info');
        document.getElementById('set-reminder-modal').classList.remove('hidden');
    }

    async createReminder() {
        const datetime = document.getElementById('reminder-datetime').value;
        const message = document.getElementById('reminder-message').value.trim();
        
        if (!datetime || !message) {
            showNotification('Please fill in all fields', 'warning');
            return;
        }
        
        if (!this.currentNoteId) {
            showNotification('No note selected for reminder', 'error');
            return;
        }
        
        const reminderTime = new Date(datetime);
        if (reminderTime <= new Date()) {
            showNotification('Reminder time must be in the future', 'warning');
            return;
        }

        try {
            const response = await window.authManager.makeAuthenticatedRequest(`${this.apiUrl}/reminders`, {
                method: 'POST',
                body: JSON.stringify({
                    noteId: this.currentNoteId,
                    reminderTime: reminderTime.toISOString(),
                    message: message
                })
            });

            if (response.ok) {
                showNotification('Reminder set successfully!', 'success');
                document.getElementById('set-reminder-modal').classList.add('hidden');
                
                // Clear form
                document.getElementById('reminder-form').reset();
                
                // Reload reminders
                this.loadReminders();
            } else {
                const error = await response.json();
                showNotification(error.error || 'Failed to create reminder', 'error');
            }
        } catch (error) {
            console.error('Create reminder error:', error);
            showNotification('Failed to create reminder', 'error');
        }
    }

    async deleteReminder(reminderId) {
        if (!confirm('Are you sure you want to delete this reminder?')) {
            return;
        }

        try {
            const response = await window.authManager.makeAuthenticatedRequest(
                `${this.apiUrl}/reminders/${reminderId}`, 
                { method: 'DELETE' }
            );

            if (response.ok) {
                showNotification('Reminder deleted successfully', 'success');
                this.loadReminders();
            } else {
                showNotification('Failed to delete reminder', 'error');
            }
        } catch (error) {
            console.error('Delete reminder error:', error);
            showNotification('Failed to delete reminder', 'error');
        }
    }

    startReminderCheck() {
        // Check for due reminders every minute
        setInterval(() => {
            this.checkDueReminders();
        }, 60000); // 1 minute
        
        // Initial check
        this.checkDueReminders();
    }

    checkDueReminders() {
        const now = new Date();
        
        this.reminders.forEach(reminder => {
            const reminderTime = new Date(reminder.reminder_time);
            const timeDiff = reminderTime.getTime() - now.getTime();
            
            // Trigger if reminder is due (within the last minute)
            if (timeDiff <= 0 && timeDiff > -60000) {
                this.triggerReminder(reminder);
            }
        });
    }

    triggerReminder(reminder) {
        // Show browser notification
        if (this.notificationPermission === 'granted') {
            const notification = new Notification('FeatherNotes Reminder', {
                body: reminder.message,
                icon: '/images/feather-icon.png',
                tag: `reminder-${reminder.id}`,
                requireInteraction: true
            });
            
            notification.onclick = () => {
                window.focus();
                // Open the note if possible
                if (window.notesManager && reminder.note_id) {
                    window.notesManager.editNote(reminder.note_id);
                }
                notification.close();
            };
        }
        
        // Show in-app notification
        showNotification(
            `Reminder: ${reminder.message}`, 
            'info', 
            8000
        );
        
        // Play notification sound (optional)
        this.playNotificationSound();
        
        // Mark reminder as triggered (you might want to implement this)
        console.log('Reminder triggered:', reminder);
    }

    playNotificationSound() {
        // Create a simple notification sound
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
        oscillator.frequency.setValueAtTime(600, audioContext.currentTime + 0.1);
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
    }

    formatReminderTime(date) {
        const now = new Date();
        const diff = date.getTime() - now.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        
        if (days > 0) {
            return date.toLocaleDateString() + ' at ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        } else if (hours > 0) {
            return 'Today at ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        } else {
            return date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        }
    }

    getTimeUntilReminder(reminderDate) {
        const now = new Date();
        const diff = reminderDate.getTime() - now.getTime();
        
        if (diff <= 0) {
            return 'Past due';
        }
        
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        
        if (days > 0) {
            return `In ${days} day${days > 1 ? 's' : ''}`;
        } else if (hours > 0) {
            return `In ${hours} hour${hours > 1 ? 's' : ''}`;
        } else if (minutes > 0) {
            return `In ${minutes} minute${minutes > 1 ? 's' : ''}`;
        } else {
            return 'Due now';
        }
    }

    // Utility function
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Add reminder-specific styles
const reminderStyles = document.createElement('style');
reminderStyles.textContent = `
    .reminder-item {
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        border-radius: 0.5rem;
        padding: 1rem;
        margin-bottom: 1rem;
        transition: all 0.2s ease;
    }

    .reminder-item:hover {
        transform: translateY(-1px);
        box-shadow: var(--shadow);
    }

    .reminder-item.past {
        opacity: 0.6;
        border-left: 4px solid var(--error-color);
    }

    .reminder-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 0.5rem;
    }

    .reminder-time {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-weight: 500;
        color: var(--primary-color);
    }

    .reminder-actions button {
        padding: 0.25rem;
        font-size: 0.75rem;
    }

    .reminder-message {
        font-size: 1rem;
        color: var(--text-primary);
        margin-bottom: 0.5rem;
        font-weight: 500;
    }

    .reminder-note {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.875rem;
        color: var(--text-secondary);
        margin-bottom: 0.5rem;
    }

    .reminder-countdown {
        font-size: 0.75rem;
        color: var(--text-muted);
        font-style: italic;
    }

    .empty-state {
        text-align: center;
        padding: 2rem;
        color: var(--text-muted);
    }

    .empty-state i {
        font-size: 2rem;
        margin-bottom: 1rem;
        opacity: 0.5;
    }

    .empty-state h4 {
        margin-bottom: 0.5rem;
        color: var(--text-secondary);
    }
`;
document.head.appendChild(reminderStyles);

// Initialize reminders manager
window.remindersManager = new RemindersManager();