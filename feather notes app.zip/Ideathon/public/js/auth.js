// Authentication Module for FeatherNotes

class AuthManager {
    constructor() {
        this.token = localStorage.getItem('feather_token');
        this.user = JSON.parse(localStorage.getItem('feather_user') || 'null');
        this.apiUrl = '/api';
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Form submissions
        document.getElementById('loginForm')?.addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('registerForm')?.addEventListener('submit', (e) => this.handleRegister(e));
        
        // Form switching
        document.getElementById('show-register')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.showRegisterForm();
        });
        
        document.getElementById('show-login')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.showLoginForm();
        });
        
        // Logout
        document.getElementById('logout-btn')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.logout();
        });
    }

    async handleLogin(e) {
        e.preventDefault();
        
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        
        if (!email || !password) {
            showNotification('Please fill in all fields', 'error');
            return;
        }

        // Show loading state
        const loginBtn = document.querySelector('#loginForm button[type="submit"]');
        const originalText = loginBtn.innerHTML;
        loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing in...';
        loginBtn.disabled = true;

        try {
            showNotification('Signing you in...', 'info');
            
            const response = await fetch(`${this.apiUrl}/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
            });

            const data = await response.json();

            if (response.ok) {
                this.token = data.token;
                this.user = data.user;
                
                localStorage.setItem('feather_token', this.token);
                localStorage.setItem('feather_user', JSON.stringify(this.user));
                
                showNotification(`Welcome back, ${data.user.username}!`, 'success');
                this.showMainApp();
            } else {
                showNotification(data.error || 'Login failed', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            showNotification('Unable to connect to the server. Please ensure the server is running on http://localhost:3000', 'error');
        } finally {
            // Restore button state
            loginBtn.innerHTML = originalText;
            loginBtn.disabled = false;
        }
    }

    async handleRegister(e) {
        e.preventDefault();
        
        const username = document.getElementById('registerUsername').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;
        
        if (!username || !email || !password) {
            showNotification('Please fill in all fields', 'error');
            return;
        }

        if (password.length < 6) {
            showNotification('Password must be at least 6 characters', 'error');
            return;
        }

        // Show loading state
        const registerBtn = document.querySelector('#registerForm button[type="submit"]');
        const originalText = registerBtn.innerHTML;
        registerBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
        registerBtn.disabled = true;

        try {
            showNotification('Creating your account...', 'info');
            
            const response = await fetch(`${this.apiUrl}/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, email, password }),
            });

            const data = await response.json();

            if (response.ok) {
                this.token = data.token;
                this.user = data.user;
                
                localStorage.setItem('feather_token', this.token);
                localStorage.setItem('feather_user', JSON.stringify(this.user));
                
                showNotification(`Welcome to FeatherNotes, ${data.user.username}!`, 'success');
                this.showMainApp();
            } else {
                showNotification(data.error || 'Registration failed', 'error');
            }
        } catch (error) {
            console.error('Registration error:', error);
            showNotification('Unable to connect to the server. Please ensure the server is running on http://localhost:3000', 'error');
        } finally {
            // Restore button state
            registerBtn.innerHTML = originalText;
            registerBtn.disabled = false;
        }
    }

    showLoginForm() {
        document.getElementById('login-form').classList.add('active');
        document.getElementById('register-form').classList.remove('active');
    }

    showRegisterForm() {
        document.getElementById('register-form').classList.add('active');
        document.getElementById('login-form').classList.remove('active');
    }

    showMainApp() {
        document.getElementById('auth-modal').classList.add('hidden');
        document.getElementById('main-app').classList.remove('hidden');
        
        // Update user info in header
        const userNameElement = document.getElementById('user-name');
        if (userNameElement && this.user) {
            userNameElement.textContent = this.user.username;
        }
        
        // Apply saved theme
        if (this.user && this.user.theme) {
            document.documentElement.setAttribute('data-theme', this.user.theme);
            this.updateThemeToggle();
        }
        
        // Show tutorial for first-time users or welcome message
        setTimeout(() => {
            if (window.tutorialManager && window.tutorialManager.isFirstTime) {
                window.tutorialManager.showTutorial();
            } else {
                showNotification(`Welcome back to FeatherNotes! 🪶 Your notes are securely stored locally.`, 'success', 5000);
            }
        }, 1000);
        
        // Load user's notes
        if (window.notesManager) {
            window.notesManager.loadNotes();
        }
        
        // Load reminders
        if (window.remindersManager) {
            window.remindersManager.loadReminders();
        }
    }

    showAuthModal() {
        document.getElementById('main-app').classList.add('hidden');
        document.getElementById('auth-modal').classList.remove('hidden');
        this.showLoginForm();
    }

    logout() {
        this.token = null;
        this.user = null;
        
        localStorage.removeItem('feather_token');
        localStorage.removeItem('feather_user');
        
        showNotification('Logged out successfully', 'info');
        this.showAuthModal();
    }

    isAuthenticated() {
        return !!this.token;
    }

    getAuthHeaders() {
        return {
            'Authorization': `Bearer ${this.token}`,
            'Content-Type': 'application/json',
        };
    }

    async makeAuthenticatedRequest(url, options = {}) {
        const headers = {
            ...this.getAuthHeaders(),
            ...options.headers,
        };

        try {
            const response = await fetch(url, {
                ...options,
                headers,
            });

            if (response.status === 401) {
                this.logout();
                throw new Error('Authentication failed');
            }

            return response;
        } catch (error) {
            console.error('Authenticated request error:', error);
            throw error;
        }
    }

    async updateUserTheme(theme) {
        try {
            const response = await this.makeAuthenticatedRequest(`${this.apiUrl}/user/theme`, {
                method: 'PUT',
                body: JSON.stringify({ theme }),
            });

            if (response.ok) {
                this.user.theme = theme;
                localStorage.setItem('feather_user', JSON.stringify(this.user));
                document.documentElement.setAttribute('data-theme', theme);
                this.updateThemeToggle();
                showNotification('Theme updated!', 'success');
            } else {
                showNotification('Failed to update theme', 'error');
            }
        } catch (error) {
            console.error('Theme update error:', error);
            showNotification('Failed to update theme', 'error');
        }
    }

    updateThemeToggle() {
        const themeToggle = document.getElementById('theme-toggle');
        const icon = themeToggle?.querySelector('i');
        
        if (icon) {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            if (currentTheme === 'dark') {
                icon.className = 'fas fa-sun';
                themeToggle.title = 'Switch to Light Theme';
            } else {
                icon.className = 'fas fa-moon';
                themeToggle.title = 'Switch to Dark Theme';
            }
        }
    }
}

// Initialize authentication manager
window.authManager = new AuthManager();