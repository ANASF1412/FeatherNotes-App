// Tutorial Module for FeatherNotes

class TutorialManager {
    constructor() {
        this.isFirstTime = localStorage.getItem('feather_tutorial_seen') !== 'true';
        this.currentStep = 0;
        this.steps = [
            {
                target: '#add-note',
                title: 'Create Your First Note',
                content: 'Click here or press Ctrl+N to create a new note. Start writing your thoughts, ideas, or reminders!'
            },
            {
                target: '#set-reminder-btn',
                title: 'Set Reminders for Notes',
                content: 'When editing a note, click the bell icon to set custom reminders. Never forget important notes again!'
            },
            {
                target: '#ai-assist-btn',
                title: 'AI Writing Assistant',
                content: 'Get smart writing suggestions and improvements from our AI assistant to enhance your notes.'
            },
            {
                target: '#theme-toggle',
                title: 'Dark/Light Theme',
                content: 'Toggle between dark and light themes to match your preference and reduce eye strain.'
            },
            {
                target: '#searchNotes',
                title: 'Search Your Notes',
                content: 'Quickly find any note using the search bar. Search by title, content, or tags.'
            }
        ];
    }

    showTutorial() {
        if (!this.isFirstTime) return;

        // Show welcome tutorial
        this.showWelcomeModal();
    }

    showWelcomeModal() {
        const welcomeHtml = `
            <div id="welcome-modal" class="modal">
                <div class="modal-content tutorial-modal">
                    <div class="tutorial-header">
                        <h2><i class="fas fa-feather-alt"></i> Welcome to FeatherNotes!</h2>
                        <p>Your intelligent note-taking companion with AI assistance</p>
                    </div>
                    <div class="tutorial-body">
                        <div class="tutorial-features">
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <i class="fas fa-bell"></i>
                                </div>
                                <div class="feature-content">
                                    <h3>Smart Reminders</h3>
                                    <p>Set custom reminders for any note. Click the bell icon when editing notes to never forget important information.</p>
                                </div>
                            </div>
                            
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <i class="fas fa-magic"></i>
                                </div>
                                <div class="feature-content">
                                    <h3>AI Writing Assistant</h3>
                                    <p>Get intelligent suggestions to improve your writing and organize your thoughts better.</p>
                                </div>
                            </div>
                            
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <i class="fas fa-shield-alt"></i>
                                </div>
                                <div class="feature-content">
                                    <h3>Secure & Private</h3>
                                    <p>Your notes are stored securely with optional encryption for sensitive content.</p>
                                </div>
                            </div>
                            
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <i class="fas fa-tags"></i>
                                </div>
                                <div class="feature-content">
                                    <h3>Smart Organization</h3>
                                    <p>Use tags, colors, and search to organize and find your notes quickly.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="tutorial-tips">
                            <h3><i class="fas fa-lightbulb"></i> Quick Tips</h3>
                            <ul>
                                <li><strong>Keyboard Shortcuts:</strong> Press Ctrl+N for new note, Ctrl+K to search</li>
                                <li><strong>Reminders:</strong> Set reminders for important notes using the bell icon</li>
                                <li><strong>Themes:</strong> Toggle dark/light mode with the theme button</li>
                                <li><strong>AI Help:</strong> Use the AI assistant for writing suggestions</li>
                                <li><strong>Local Storage:</strong> Your data is stored securely on your device</li>
                            </ul>
                        </div>
                    </div>
                    <div class="tutorial-footer">
                        <button class="btn btn-secondary" onclick="tutorialManager.skipTutorial()">
                            Skip Tutorial
                        </button>
                        <button class="btn btn-primary" onclick="tutorialManager.startTutorial()">
                            <i class="fas fa-rocket"></i> Get Started
                        </button>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', welcomeHtml);
        document.getElementById('welcome-modal').classList.remove('hidden');
    }

    startTutorial() {
        this.closeWelcomeModal();
        localStorage.setItem('feather_tutorial_seen', 'true');
        
        // Show first note creation tip
        setTimeout(() => {
            showNotification('💡 Click the "New Note" button to create your first note!', 'info', 6000);
        }, 500);
        
        // Show reminder tip after 10 seconds
        setTimeout(() => {
            showNotification('🔔 Pro tip: When editing notes, click the bell icon to set reminders!', 'info', 8000);
        }, 10000);
    }

    skipTutorial() {
        this.closeWelcomeModal();
        localStorage.setItem('feather_tutorial_seen', 'true');
        showNotification('Welcome to FeatherNotes! Explore the features at your own pace.', 'success');
    }

    closeWelcomeModal() {
        const modal = document.getElementById('welcome-modal');
        if (modal) {
            modal.remove();
        }
    }

    // Show contextual tips based on user actions
    showContextualTip(action) {
        const tips = {
            'first-note': 'Great! Now try adding some content and setting a reminder with the bell icon.',
            'reminder-set': 'Awesome! You\'ll get a notification when your reminder is due.',
            'ai-used': 'Nice! The AI assistant can help improve your writing and suggest better organization.',
            'theme-changed': 'Perfect! Your theme preference will be saved for next time.',
            'search-used': 'Great! You can search through all your notes, tags, and content.'
        };

        if (tips[action]) {
            showNotification(`💡 ${tips[action]}`, 'info', 5000);
        }
    }

    // Reset tutorial (for testing)
    resetTutorial() {
        localStorage.removeItem('feather_tutorial_seen');
        this.isFirstTime = true;
        showNotification('Tutorial reset! Refresh the page to see it again.', 'success');
    }
}

// Add tutorial-specific styles
const tutorialStyles = document.createElement('style');
tutorialStyles.textContent = `
    .tutorial-modal {
        width: 90vw;
        max-width: 700px;
        max-height: 90vh;
        overflow-y: auto;
    }

    .tutorial-header {
        text-align: center;
        padding: 2rem 2rem 1rem;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
        border-radius: 1rem 1rem 0 0;
    }

    .tutorial-header h2 {
        margin-bottom: 0.5rem;
        font-size: 1.75rem;
    }

    .tutorial-header p {
        opacity: 0.9;
        font-size: 1rem;
    }

    .tutorial-body {
        padding: 2rem;
    }

    .tutorial-features {
        margin-bottom: 2rem;
    }

    .feature-item {
        display: flex;
        align-items: flex-start;
        gap: 1rem;
        margin-bottom: 1.5rem;
        padding: 1rem;
        background: var(--bg-secondary);
        border-radius: 0.5rem;
        transition: transform 0.2s ease;
    }

    .feature-item:hover {
        transform: translateY(-1px);
    }

    .feature-icon {
        flex-shrink: 0;
        width: 3rem;
        height: 3rem;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--primary-color);
        color: white;
        border-radius: 50%;
        font-size: 1.25rem;
    }

    .feature-content h3 {
        margin-bottom: 0.5rem;
        color: var(--text-primary);
        font-size: 1.1rem;
    }

    .feature-content p {
        color: var(--text-secondary);
        line-height: 1.5;
    }

    .tutorial-tips {
        background: var(--bg-tertiary);
        padding: 1.5rem;
        border-radius: 0.5rem;
        border-left: 4px solid var(--accent-color);
    }

    .tutorial-tips h3 {
        color: var(--accent-color);
        margin-bottom: 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .tutorial-tips ul {
        margin-left: 1rem;
    }

    .tutorial-tips li {
        margin-bottom: 0.75rem;
        color: var(--text-secondary);
        line-height: 1.6;
    }

    .tutorial-tips strong {
        color: var(--text-primary);
    }

    .tutorial-footer {
        display: flex;
        gap: 1rem;
        justify-content: flex-end;
        padding: 1.5rem 2rem 2rem;
        border-top: 1px solid var(--border-color);
    }

    @media (max-width: 768px) {
        .tutorial-modal {
            width: 95vw;
            margin: 1rem;
        }

        .feature-item {
            flex-direction: column;
            text-align: center;
        }

        .tutorial-footer {
            flex-direction: column;
        }
    }
`;
document.head.appendChild(tutorialStyles);

// Initialize tutorial manager
window.tutorialManager = new TutorialManager();