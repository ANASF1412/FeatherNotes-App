// AI Assistant Module for FeatherNotes

class AIAssistant {
    constructor() {
        this.apiUrl = '/api';
        this.suggestions = [
            "Organize your thoughts with bullet points",
            "Add relevant tags to make notes searchable",
            "Use headings to structure your content",
            "Include dates and references for context",
            "Break down complex topics into smaller sections",
            "Use formatting to highlight important information",
            "Add visual elements like lists or tables",
            "Include action items or next steps",
            "Cross-reference related notes",
            "Summarize key points at the end"
        ];
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // AI Assistant button in sidebar
        document.getElementById('ai-assist-btn')?.addEventListener('click', () => {
            this.showAIModal();
        });
        
        // AI Help button in note editor
        document.getElementById('ai-help-btn')?.addEventListener('click', () => {
            this.showAIModal();
        });
        
        // Get AI help button
        document.getElementById('get-ai-help')?.addEventListener('click', () => {
            this.getAIHelp();
        });
        
        // Close AI modal
        document.querySelector('#ai-modal .close-modal')?.addEventListener('click', () => {
            this.closeAIModal();
        });
    }

    showAIModal() {
        this.loadSuggestions();
        document.getElementById('ai-modal').classList.remove('hidden');
        
        // Focus on the AI prompt input
        setTimeout(() => {
            document.getElementById('ai-prompt')?.focus();
        }, 100);
    }

    closeAIModal() {
        document.getElementById('ai-modal').classList.add('hidden');
        document.getElementById('ai-prompt').value = '';
    }

    loadSuggestions() {
        const suggestionsList = document.getElementById('ai-suggestions-list');
        if (!suggestionsList) return;

        // Get context from current note if available
        const currentNote = window.notesManager?.currentNote;
        let contextualSuggestions = [...this.suggestions];

        if (currentNote && currentNote.content) {
            const content = currentNote.content.toLowerCase();
            
            // Add contextual suggestions based on content
            if (content.includes('meeting') || content.includes('discussion')) {
                contextualSuggestions.unshift("Add meeting attendees and action items");
                contextualSuggestions.unshift("Include key decisions made");
            }
            
            if (content.includes('project') || content.includes('task')) {
                contextualSuggestions.unshift("Add project timeline and milestones");
                contextualSuggestions.unshift("Include project stakeholders");
            }
            
            if (content.includes('idea') || content.includes('concept')) {
                contextualSuggestions.unshift("Develop the idea with pros and cons");
                contextualSuggestions.unshift("Add potential implementation steps");
            }
            
            if (content.includes('research') || content.includes('study')) {
                contextualSuggestions.unshift("Add sources and references");
                contextualSuggestions.unshift("Include methodology and findings");
            }
        }

        // Shuffle suggestions and take top 5
        const shuffled = contextualSuggestions.sort(() => 0.5 - Math.random());
        const topSuggestions = shuffled.slice(0, 5);

        suggestionsList.innerHTML = topSuggestions.map(suggestion => 
            `<div class="suggestion-item" onclick="aiAssistant.applySuggestion('${suggestion}')">
                <i class="fas fa-lightbulb"></i>
                ${suggestion}
            </div>`
        ).join('');
    }

    applySuggestion(suggestion) {
        // Add the suggestion to the AI prompt
        const promptInput = document.getElementById('ai-prompt');
        if (promptInput) {
            promptInput.value = `Help me ${suggestion.toLowerCase()} in my note.`;
            promptInput.focus();
        }
    }

    async getAIHelp() {
        const prompt = document.getElementById('ai-prompt').value.trim();
        
        if (!prompt) {
            showNotification('Please enter a prompt for AI assistance', 'warning');
            return;
        }

        const getHelpBtn = document.getElementById('get-ai-help');
        const originalText = getHelpBtn.innerHTML;
        
        // Show loading state
        getHelpBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Getting help...';
        getHelpBtn.disabled = true;

        try {
            // Get current note content as context
            const currentNote = window.notesManager?.currentNote;
            const context = currentNote ? {
                title: currentNote.title,
                content: currentNote.content
            } : null;

            const response = await window.authManager.makeAuthenticatedRequest(`${this.apiUrl}/ai/assist`, {
                method: 'POST',
                body: JSON.stringify({
                    prompt: prompt,
                    context: context
                })
            });

            if (response.ok) {
                const data = await response.json();
                this.displayAIResponse(data);
            } else {
                throw new Error('AI service unavailable');
            }
        } catch (error) {
            console.error('AI assistance error:', error);
            
            // Provide fallback assistance
            this.provideFallbackAssistance(prompt);
        } finally {
            // Restore button state
            getHelpBtn.innerHTML = originalText;
            getHelpBtn.disabled = false;
        }
    }

    displayAIResponse(data) {
        const suggestionsList = document.getElementById('ai-suggestions-list');
        if (!suggestionsList) return;

        let responseHtml = '<div class="ai-response">';
        responseHtml += '<h4><i class="fas fa-robot"></i> AI Suggestions</h4>';
        
        if (data.suggestions && data.suggestions.length > 0) {
            responseHtml += '<ul>';
            data.suggestions.forEach(suggestion => {
                responseHtml += `<li>${suggestion}</li>`;
            });
            responseHtml += '</ul>';
        }
        
        if (data.enhancedText) {
            responseHtml += '<div class="enhanced-text">';
            responseHtml += '<h5>Enhanced Text:</h5>';
            responseHtml += `<p>${data.enhancedText}</p>`;
            responseHtml += '<button class="btn btn-primary btn-sm" onclick="aiAssistant.applyEnhancedText(\`' + 
                           data.enhancedText + '\`)">Apply to Note</button>';
            responseHtml += '</div>';
        }
        
        responseHtml += '</div>';
        
        suggestionsList.innerHTML = responseHtml;
    }

    provideFallbackAssistance(prompt) {
        const suggestionsList = document.getElementById('ai-suggestions-list');
        if (!suggestionsList) return;

        const keywords = prompt.toLowerCase();
        let fallbackSuggestions = [];

        // Provide suggestions based on keywords
        if (keywords.includes('organize') || keywords.includes('structure')) {
            fallbackSuggestions = [
                "Use headings (H1, H2, H3) to create a hierarchy",
                "Break content into logical sections",
                "Use bullet points for lists",
                "Add a summary at the top",
                "Include a table of contents for long notes"
            ];
        } else if (keywords.includes('improve') || keywords.includes('enhance')) {
            fallbackSuggestions = [
                "Add more specific details and examples",
                "Include relevant dates and references",
                "Use bold text to highlight key points",
                "Add visual elements like tables or lists",
                "Include action items or next steps"
            ];
        } else if (keywords.includes('meeting') || keywords.includes('discussion')) {
            fallbackSuggestions = [
                "Add meeting date, time, and attendees",
                "List agenda items discussed",
                "Include key decisions made",
                "Add action items with responsible persons",
                "Note any follow-up meetings scheduled"
            ];
        } else if (keywords.includes('project') || keywords.includes('task')) {
            fallbackSuggestions = [
                "Define project scope and objectives",
                "List required resources and timeline",
                "Identify key stakeholders",
                "Break down into smaller tasks",
                "Add progress tracking methods"
            ];
        } else {
            fallbackSuggestions = [
                "Add more context and background information",
                "Include relevant links and references",
                "Use formatting to improve readability",
                "Add tags for better organization",
                "Include related notes or cross-references"
            ];
        }

        let responseHtml = '<div class="ai-response">';
        responseHtml += '<h4><i class="fas fa-lightbulb"></i> Writing Suggestions</h4>';
        responseHtml += '<ul>';
        fallbackSuggestions.forEach(suggestion => {
            responseHtml += `<li>${suggestion}</li>`;
        });
        responseHtml += '</ul>';
        responseHtml += '</div>';

        suggestionsList.innerHTML = responseHtml;
    }

    applyEnhancedText(text) {
        // Apply the enhanced text to the current note
        const noteContent = document.getElementById('note-content');
        if (noteContent && window.notesManager?.isEditing) {
            noteContent.innerHTML = text;
            showNotification('Enhanced text applied to note!', 'success');
            this.closeAIModal();
            
            // Update word count
            window.notesManager.updateWordCount();
        } else {
            showNotification('No note is currently being edited', 'warning');
        }
    }

    // Smart writing suggestions based on content analysis
    analyzeContent(content) {
        const suggestions = [];
        
        // Check for common writing issues
        if (content.length < 50) {
            suggestions.push("Consider adding more detail to your note");
        }
        
        if (!content.includes('.') && !content.includes('!') && !content.includes('?')) {
            suggestions.push("Add proper punctuation to improve readability");
        }
        
        if (content.split(' ').length > 200 && !content.includes('\n')) {
            suggestions.push("Break up long paragraphs for better readability");
        }
        
        if (content.toLowerCase().includes('todo') || content.toLowerCase().includes('task')) {
            suggestions.push("Consider creating a checklist format for tasks");
        }
        
        if (content.toLowerCase().includes('important') || content.toLowerCase().includes('urgent')) {
            suggestions.push("Use bold formatting to highlight important information");
        }
        
        return suggestions;
    }

    // Auto-suggest tags based on content
    suggestTags(content) {
        const commonTags = {
            'meeting': ['meeting', 'discussion', 'agenda'],
            'project': ['project', 'work', 'planning'],
            'idea': ['idea', 'brainstorm', 'creative'],
            'research': ['research', 'study', 'analysis'],
            'personal': ['personal', 'diary', 'journal'],
            'work': ['work', 'professional', 'business'],
            'learning': ['learning', 'education', 'notes'],
            'travel': ['travel', 'trip', 'vacation'],
            'health': ['health', 'fitness', 'medical'],
            'finance': ['finance', 'money', 'budget']
        };
        
        const suggestedTags = [];
        const lowerContent = content.toLowerCase();
        
        Object.entries(commonTags).forEach(([category, keywords]) => {
            if (keywords.some(keyword => lowerContent.includes(keyword))) {
                suggestedTags.push(category);
            }
        });
        
        return suggestedTags;
    }

    // Real-time writing assistance
    provideRealTimeAssistance() {
        const noteContent = document.getElementById('note-content');
        if (!noteContent) return;

        noteContent.addEventListener('input', () => {
            const content = noteContent.textContent || '';
            
            // Provide suggestions after user stops typing
            clearTimeout(this.assistanceTimer);
            this.assistanceTimer = setTimeout(() => {
                const suggestions = this.analyzeContent(content);
                const tags = this.suggestTags(content);
                
                // Show subtle suggestions (you can implement a small suggestion box)
                if (suggestions.length > 0 || tags.length > 0) {
                    this.showInlineAssistance(suggestions, tags);
                }
            }, 2000);
        });
    }

    showInlineAssistance(suggestions, tags) {
        // Remove existing assistance
        const existingAssistance = document.querySelector('.inline-assistance');
        if (existingAssistance) {
            existingAssistance.remove();
        }

        if (suggestions.length === 0 && tags.length === 0) return;

        // Create assistance popup
        const assistance = document.createElement('div');
        assistance.className = 'inline-assistance';
        assistance.innerHTML = `
            <div class="assistance-content">
                <h5><i class="fas fa-lightbulb"></i> AI Suggestions</h5>
                ${suggestions.length > 0 ? `
                    <div class="suggestions">
                        ${suggestions.map(s => `<div class="suggestion">${s}</div>`).join('')}
                    </div>
                ` : ''}
                ${tags.length > 0 ? `
                    <div class="tag-suggestions">
                        <strong>Suggested tags:</strong>
                        ${tags.map(tag => `<span class="suggested-tag" onclick="aiAssistant.addTag('${tag}')">${tag}</span>`).join('')}
                    </div>
                ` : ''}
                <button class="close-assistance" onclick="this.parentElement.parentElement.remove()">×</button>
            </div>
        `;

        document.body.appendChild(assistance);

        // Auto-hide after 10 seconds
        setTimeout(() => {
            if (assistance.parentElement) {
                assistance.remove();
            }
        }, 10000);
    }

    addTag(tag) {
        const tagsInput = document.getElementById('note-tags');
        if (tagsInput) {
            const currentTags = tagsInput.value.split(',').map(t => t.trim()).filter(t => t);
            if (!currentTags.includes(tag)) {
                currentTags.push(tag);
                tagsInput.value = currentTags.join(', ');
            }
        }
        
        // Remove the suggestion
        const assistance = document.querySelector('.inline-assistance');
        if (assistance) {
            assistance.remove();
        }
    }
}

// Add AI-specific styles
const aiStyles = document.createElement('style');
aiStyles.textContent = `
    .ai-response {
        background: var(--bg-tertiary);
        border-radius: 0.5rem;
        padding: 1rem;
        margin-top: 1rem;
    }

    .ai-response h4 {
        margin-bottom: 0.75rem;
        color: var(--primary-color);
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .ai-response ul {
        margin-left: 1rem;
        margin-bottom: 1rem;
    }

    .ai-response li {
        margin-bottom: 0.5rem;
        color: var(--text-secondary);
    }

    .enhanced-text {
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid var(--border-color);
    }

    .enhanced-text h5 {
        margin-bottom: 0.5rem;
        color: var(--text-primary);
    }

    .enhanced-text p {
        background: var(--bg-secondary);
        padding: 0.75rem;
        border-radius: 0.25rem;
        margin-bottom: 0.75rem;
        color: var(--text-secondary);
    }

    .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.75rem;
    }

    .inline-assistance {
        position: fixed;
        bottom: 2rem;
        right: 2rem;
        background: var(--bg-primary);
        border: 1px solid var(--border-color);
        border-radius: 0.5rem;
        box-shadow: var(--shadow-lg);
        max-width: 300px;
        z-index: 1000;
        animation: slideInUp 0.3s ease;
    }

    .assistance-content {
        padding: 1rem;
        position: relative;
    }

    .assistance-content h5 {
        margin-bottom: 0.75rem;
        color: var(--primary-color);
        font-size: 0.875rem;
    }

    .suggestion {
        background: var(--bg-secondary);
        padding: 0.5rem;
        border-radius: 0.25rem;
        margin-bottom: 0.5rem;
        font-size: 0.75rem;
        color: var(--text-secondary);
    }

    .tag-suggestions {
        margin-top: 0.75rem;
        font-size: 0.75rem;
    }

    .suggested-tag {
        display: inline-block;
        background: var(--primary-color);
        color: white;
        padding: 0.25rem 0.5rem;
        border-radius: 1rem;
        margin: 0.25rem 0.25rem 0 0;
        cursor: pointer;
        font-size: 0.625rem;
    }

    .suggested-tag:hover {
        background: var(--secondary-color);
    }

    .close-assistance {
        position: absolute;
        top: 0.5rem;
        right: 0.5rem;
        background: none;
        border: none;
        font-size: 1rem;
        color: var(--text-muted);
        cursor: pointer;
        padding: 0.25rem;
    }

    .close-assistance:hover {
        color: var(--text-primary);
    }

    @keyframes slideInUp {
        from {
            transform: translateY(100%);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
`;
document.head.appendChild(aiStyles);

// Initialize AI assistant
window.aiAssistant = new AIAssistant();