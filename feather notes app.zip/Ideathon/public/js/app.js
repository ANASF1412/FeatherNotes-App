// Main Application Module for FeatherNotes

class FeatherNotesApp {
    constructor() {
        this.isInitialized = false;
        this.initializeApp();
    }

    async initializeApp() {
        console.log('🪶 Initializing FeatherNotes...');
        
        // Show loading screen
        this.showLoadingScreen();
        
        try {
            // Wait for DOM to be fully loaded
            if (document.readyState !== 'complete') {
                await new Promise(resolve => {
                    window.addEventListener('load', resolve);
                });
            }
            
            // Test server connection
            await this.testServerConnection();
            
            // Initialize core modules
            await this.initializeModules();
            
            // Check authentication state
            this.checkAuthenticationState();
            
            // Setup global event listeners
            this.setupGlobalEventListeners();
            
            // Initialize responsive design
            this.initializeResponsiveDesign();
            
            // Setup keyboard shortcuts
            this.setupKeyboardShortcuts();
            
            // Initialize real-time features
            this.initializeRealTimeFeatures();
            
            // Hide loading screen
            this.hideLoadingScreen();
            
            console.log('✅ FeatherNotes initialized successfully');
            this.isInitialized = true;
            
        } catch (error) {
            console.error('❌ Failed to initialize FeatherNotes:', error);
            this.showErrorState();
        }
    }

    async testServerConnection() {
        try {
            const response = await fetch('/api/health');
            if (!response.ok) {
                throw new Error('Server not responding');
            }
            console.log('✅ Server connection established');
        } catch (error) {
            console.log('⚠️ Server connection issue - app will use local storage for backup');
            showNotification('Connected to FeatherNotes - using local database', 'info');
        }
    }

    showLoadingScreen() {
        const loadingScreen = document.getElementById('loading-screen');
        if (loadingScreen) {
            loadingScreen.style.display = 'flex';
        }
    }

    hideLoadingScreen() {
        const loadingScreen = document.getElementById('loading-screen');
        if (loadingScreen) {
            setTimeout(() => {
                loadingScreen.style.opacity = '0';
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                }, 500);
            }, 1000); // Show loading for at least 1 second
        }
    }

    async initializeModules() {
        // Modules are already initialized via their constructors
        // This method can be used for any additional setup
        
        // Initialize UI manager responsive features
        if (window.uiManager) {
            window.uiManager.initializeResponsive();
        }
        
        // Initialize AI real-time assistance
        if (window.aiAssistant) {
            window.aiAssistant.provideRealTimeAssistance();
        }
        
        console.log('📦 All modules initialized');
    }

    checkAuthenticationState() {
        if (window.authManager && window.authManager.isAuthenticated()) {
            console.log('👤 User is authenticated');
            window.authManager.showMainApp();
        } else {
            console.log('🔑 User needs to authenticate');
            window.authManager.showAuthModal();
        }
    }

    setupGlobalEventListeners() {
        // Handle online/offline status
        window.addEventListener('online', () => {
            showNotification('Connection restored', 'success');
            this.syncWhenOnline();
        });

        window.addEventListener('offline', () => {
            showNotification('Working offline', 'warning');
        });

        // Handle page visibility changes
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && window.authManager?.isAuthenticated()) {
                // Refresh data when page becomes visible
                this.refreshData();
            }
        });

        // Handle beforeunload to save any unsaved changes
        window.addEventListener('beforeunload', (e) => {
            if (window.notesManager?.isEditing) {
                e.preventDefault();
                e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
                return e.returnValue;
            }
        });

        // Handle global error events
        window.addEventListener('error', (e) => {
            console.error('Global error:', e.error);
            showNotification('An unexpected error occurred', 'error');
        });

        window.addEventListener('unhandledrejection', (e) => {
            console.error('Unhandled promise rejection:', e.reason);
            showNotification('A network error occurred', 'error');
        });
    }

    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Global shortcuts (when not editing)
            if (!window.notesManager?.isEditing) {
                // Ctrl/Cmd + K: Focus search
                if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                    e.preventDefault();
                    const searchInput = document.getElementById('searchNotes');
                    if (searchInput) {
                        searchInput.focus();
                        searchInput.select();
                    }
                }
                
                // Ctrl/Cmd + /: Show keyboard shortcuts
                if ((e.ctrlKey || e.metaKey) && e.key === '/') {
                    e.preventDefault();
                    this.showKeyboardShortcuts();
                }
                
                // Alt + T: Toggle theme
                if (e.altKey && e.key === 't') {
                    e.preventDefault();
                    window.uiManager?.toggleTheme();
                }
                
                // Alt + R: Show reminders
                if (e.altKey && e.key === 'r') {
                    e.preventDefault();
                    window.remindersManager?.showRemindersModal();
                }
                
                // Alt + A: Show AI assistant
                if (e.altKey && e.key === 'a') {
                    e.preventDefault();
                    window.aiAssistant?.showAIModal();
                }
            }
        });
    }

    initializeResponsiveDesign() {
        // Handle screen size changes
        const handleResize = () => {
            const isMobile = window.innerWidth <= 768;
            document.body.classList.toggle('mobile', isMobile);
            
            // Adjust layout for mobile
            if (isMobile) {
                this.optimizeForMobile();
            } else {
                this.optimizeForDesktop();
            }
        };

        handleResize();
        window.addEventListener('resize', handleResize);
    }

    optimizeForMobile() {
        // Hide sidebar on mobile
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.style.display = 'none';
        }
        
        // Adjust header layout
        const header = document.querySelector('.header');
        if (header) {
            header.classList.add('mobile-header');
        }
    }

    optimizeForDesktop() {
        // Show sidebar on desktop
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.style.display = 'block';
        }
        
        // Reset header layout
        const header = document.querySelector('.header');
        if (header) {
            header.classList.remove('mobile-header');
        }
    }

    initializeRealTimeFeatures() {
        // Auto-save functionality
        this.setupAutoSave();
        
        // Periodic data refresh
        this.setupPeriodicRefresh();
        
        // Real-time collaboration (placeholder for future)
        this.setupCollaboration();
    }

    setupAutoSave() {
        let autoSaveTimer;
        
        const autoSave = () => {
            if (window.notesManager?.isEditing && window.notesManager?.currentNote) {
                const title = document.getElementById('note-title')?.value;
                const content = document.getElementById('note-content')?.innerHTML;
                
                if (title || content) {
                    // Save to localStorage as backup
                    const backupData = {
                        id: window.notesManager.currentNote.id,
                        title: title,
                        content: content,
                        timestamp: Date.now()
                    };
                    
                    localStorage.setItem('feather_autosave', JSON.stringify(backupData));
                    console.log('📄 Auto-saved note backup');
                }
            }
        };

        // Auto-save every 30 seconds while editing
        document.addEventListener('input', (e) => {
            if (e.target.closest('.note-editor')) {
                clearTimeout(autoSaveTimer);
                autoSaveTimer = setTimeout(autoSave, 30000);
            }
        });
    }

    setupPeriodicRefresh() {
        // Refresh notes every 5 minutes if authenticated
        setInterval(() => {
            if (window.authManager?.isAuthenticated() && !window.notesManager?.isEditing) {
                this.refreshData();
            }
        }, 5 * 60 * 1000); // 5 minutes
    }

    setupCollaboration() {
        // Placeholder for real-time collaboration features
        // This could include WebSocket connections, conflict resolution, etc.
        console.log('🤝 Collaboration features ready for implementation');
    }

    async refreshData() {
        try {
            if (window.notesManager) {
                await window.notesManager.loadNotes();
            }
            
            if (window.remindersManager) {
                await window.remindersManager.loadReminders();
            }
            
            console.log('🔄 Data refreshed');
        } catch (error) {
            console.error('Failed to refresh data:', error);
        }
    }

    async syncWhenOnline() {
        if (navigator.onLine && window.authManager?.isAuthenticated()) {
            try {
                await this.refreshData();
                showNotification('Data synchronized', 'success');
            } catch (error) {
                console.error('Sync failed:', error);
                showNotification('Failed to sync data', 'error');
            }
        }
    }

    showKeyboardShortcuts() {
        const shortcutsHtml = `
            <div id="shortcuts-modal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><i class="fas fa-keyboard"></i> Keyboard Shortcuts</h3>
                        <button class="close-modal" onclick="closeModal('shortcuts-modal')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="shortcuts-grid">
                            <div class="shortcut-section">
                                <h4>General</h4>
                                <div class="shortcut-item">
                                    <kbd>Ctrl/Cmd + N</kbd>
                                    <span>New Note</span>
                                </div>
                                <div class="shortcut-item">
                                    <kbd>Ctrl/Cmd + K</kbd>
                                    <span>Focus Search</span>
                                </div>
                                <div class="shortcut-item">
                                    <kbd>Alt + T</kbd>
                                    <span>Toggle Theme</span>
                                </div>
                                <div class="shortcut-item">
                                    <kbd>Ctrl/Cmd + /</kbd>
                                    <span>Show Shortcuts</span>
                                </div>
                            </div>
                            
                            <div class="shortcut-section">
                                <h4>Note Editing</h4>
                                <div class="shortcut-item">
                                    <kbd>Ctrl/Cmd + S</kbd>
                                    <span>Save Note</span>
                                </div>
                                <div class="shortcut-item">
                                    <kbd>Ctrl/Cmd + B</kbd>
                                    <span>Bold Text</span>
                                </div>
                                <div class="shortcut-item">
                                    <kbd>Ctrl/Cmd + I</kbd>
                                    <span>Italic Text</span>
                                </div>
                                <div class="shortcut-item">
                                    <kbd>Escape</kbd>
                                    <span>Close Editor</span>
                                </div>
                            </div>
                            
                            <div class="shortcut-section">
                                <h4>Features</h4>
                                <div class="shortcut-item">
                                    <kbd>Alt + R</kbd>
                                    <span>Show Reminders</span>
                                </div>
                                <div class="shortcut-item">
                                    <kbd>Alt + A</kbd>
                                    <span>AI Assistant</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Remove existing modal if any
        const existingModal = document.getElementById('shortcuts-modal');
        if (existingModal) {
            existingModal.remove();
        }
        
        document.body.insertAdjacentHTML('beforeend', shortcutsHtml);
        document.getElementById('shortcuts-modal').classList.remove('hidden');
    }

    showErrorState() {
        const errorHtml = `
            <div class="error-state">
                <div class="error-content">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h2>Something went wrong</h2>
                    <p>FeatherNotes encountered an error during initialization.</p>
                    <button class="btn btn-primary" onclick="location.reload()">
                        <i class="fas fa-redo"></i> Reload Application
                    </button>
                </div>
            </div>
        `;
        
        document.body.innerHTML = errorHtml;
    }

    // Utility methods
    getAppStats() {
        return {
            isInitialized: this.isInitialized,
            isAuthenticated: window.authManager?.isAuthenticated() || false,
            notesCount: window.notesManager?.notes?.length || 0,
            remindersCount: window.remindersManager?.reminders?.length || 0,
            theme: document.documentElement.getAttribute('data-theme'),
            lastActive: new Date().toISOString()
        };
    }

    // Export app data
    async exportAppData() {
        if (!window.authManager?.isAuthenticated()) {
            showNotification('Please log in to export data', 'warning');
            return;
        }

        try {
            const appData = {
                notes: window.notesManager?.notes || [],
                reminders: window.remindersManager?.reminders || [],
                user: window.authManager?.user || {},
                exportDate: new Date().toISOString(),
                version: '1.0.0'
            };

            const dataStr = JSON.stringify(appData, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            
            const url = URL.createObjectURL(dataBlob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `feathernotes-full-export-${new Date().toISOString().split('T')[0]}.json`;
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            URL.revokeObjectURL(url);
            showNotification('Complete app data exported!', 'success');
        } catch (error) {
            console.error('Export error:', error);
            showNotification('Failed to export app data', 'error');
        }
    }
}

// Add app-specific styles
const appStyles = document.createElement('style');
appStyles.textContent = `
    .error-state {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: var(--bg-primary);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
    }

    .error-content {
        text-align: center;
        max-width: 400px;
        padding: 2rem;
    }

    .error-content i {
        font-size: 4rem;
        color: var(--error-color);
        margin-bottom: 1rem;
    }

    .error-content h2 {
        margin-bottom: 1rem;
        color: var(--text-primary);
    }

    .error-content p {
        margin-bottom: 2rem;
        color: var(--text-secondary);
    }

    .shortcuts-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 2rem;
    }

    .shortcut-section h4 {
        margin-bottom: 1rem;
        color: var(--primary-color);
        border-bottom: 1px solid var(--border-color);
        padding-bottom: 0.5rem;
    }

    .shortcut-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 0.75rem;
        padding: 0.5rem;
        border-radius: 0.25rem;
        transition: background-color 0.2s ease;
    }

    .shortcut-item:hover {
        background: var(--bg-secondary);
    }

    .shortcut-item kbd {
        background: var(--bg-tertiary);
        border: 1px solid var(--border-color);
        border-radius: 0.25rem;
        padding: 0.25rem 0.5rem;
        font-size: 0.75rem;
        font-family: monospace;
        color: var(--text-primary);
    }

    .shortcut-item span {
        color: var(--text-secondary);
    }

    .mobile-header {
        flex-wrap: wrap;
        padding: 0.75rem 1rem;
    }

    .mobile-header .header-center {
        order: 3;
        flex-basis: 100%;
        margin-top: 0.75rem;
    }

    body.mobile .notes-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }

    body.mobile .note-editor {
        width: 95vw;
        height: 95vh;
    }

    body.mobile .auth-container {
        width: 90vw;
        padding: 1.5rem;
    }
`;
document.head.appendChild(appStyles);

// Initialize the app when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.featherApp = new FeatherNotesApp();
    });
} else {
    window.featherApp = new FeatherNotesApp();
}

// Make app available globally for debugging
window.FeatherNotes = {
    app: () => window.featherApp,
    auth: () => window.authManager,
    notes: () => window.notesManager,
    ui: () => window.uiManager,
    reminders: () => window.remindersManager,
    ai: () => window.aiAssistant,
    stats: () => window.featherApp?.getAppStats(),
    export: () => window.featherApp?.exportAppData()
};