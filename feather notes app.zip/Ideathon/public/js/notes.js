// Notes Management Module for FeatherNotes

class NotesManager {
    constructor() {
        this.notes = [];
        this.currentNote = null;
        this.isEditing = false;
        this.searchQuery = '';
        this.selectedTags = [];
        this.apiUrl = '/api';
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Note creation and editing
        document.getElementById('add-note')?.addEventListener('click', () => this.createNewNote());
        document.getElementById('save-note')?.addEventListener('click', () => this.saveCurrentNote());
        document.getElementById('close-editor')?.addEventListener('click', () => this.closeEditor());
        
        // Search functionality
        document.getElementById('searchNotes')?.addEventListener('input', (e) => this.handleSearch(e.target.value));
        
        // Editor functionality
        document.getElementById('note-content')?.addEventListener('input', () => this.updateWordCount());
        document.getElementById('note-title')?.addEventListener('input', () => this.updateWordCount());
        
        // Color picker
        document.getElementById('note-color')?.addEventListener('change', (e) => this.updateNoteColor(e.target.value));
        
        // Encryption toggle
        document.getElementById('encrypt-toggle')?.addEventListener('click', () => this.toggleEncryption());
        
        // Encrypted notes filter
        document.getElementById('encrypted-notes-btn')?.addEventListener('click', () => this.showEncryptedNotes());
        
        // Modal close on outside click
        document.getElementById('note-editor-modal')?.addEventListener('click', (e) => {
            if (e.target.id === 'note-editor-modal') {
                this.closeEditor();
            }
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));
    }

    handleKeyboardShortcuts(e) {
        // Ctrl/Cmd + N: New Note
        if ((e.ctrlKey || e.metaKey) && e.key === 'n' && !this.isEditing) {
            e.preventDefault();
            this.createNewNote();
        }
        
        // Ctrl/Cmd + S: Save Note
        if ((e.ctrlKey || e.metaKey) && e.key === 's' && this.isEditing) {
            e.preventDefault();
            this.saveCurrentNote();
        }
        
        // Escape: Close Editor
        if (e.key === 'Escape' && this.isEditing) {
            this.closeEditor();
        }
    }

    async loadNotes() {
        try {
            const response = await window.authManager.makeAuthenticatedRequest(`${this.apiUrl}/notes`);
            
            if (response.ok) {
                this.notes = await response.json();
                this.renderNotes();
                this.updateTagsList();
            } else {
                showNotification('Failed to load notes', 'error');
            }
        } catch (error) {
            console.error('Load notes error:', error);
            showNotification('Failed to load notes', 'error');
        }
    }

    renderNotes() {
        const notesGrid = document.getElementById('notes-grid');
        const emptyState = document.getElementById('empty-state');
        
        if (!notesGrid) return;

        // Filter notes based on search and tags
        let filteredNotes = this.notes.filter(note => {
            const matchesSearch = !this.searchQuery || 
                note.title.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
                note.content.toLowerCase().includes(this.searchQuery.toLowerCase());
            
            const matchesTags = this.selectedTags.length === 0 || 
                this.selectedTags.some(tag => note.tags && note.tags.includes(tag));
            
            return matchesSearch && matchesTags;
        });

        if (filteredNotes.length === 0) {
            notesGrid.style.display = 'none';
            emptyState?.classList.remove('hidden');
        } else {
            notesGrid.style.display = 'grid';
            emptyState?.classList.add('hidden');
            
            notesGrid.innerHTML = filteredNotes.map(note => this.createNoteCard(note)).join('');
            
            // Add event listeners to note cards
            filteredNotes.forEach(note => {
                const noteCard = document.querySelector(`[data-note-id="${note.id}"]`);
                if (noteCard) {
                    noteCard.addEventListener('click', (e) => {
                        if (!e.target.closest('.note-actions')) {
                            this.editNote(note.id);
                        }
                    });
                }
            });
        }
    }

    createNoteCard(note) {
        const createdAt = new Date(note.created_at).toLocaleDateString();
        const tags = note.tags ? note.tags.split(',').map(tag => tag.trim()).filter(tag => tag) : [];
        const contentPreview = this.stripHtml(note.content).substring(0, 150) + '...';
        
        return `
            <div class="note-card ${note.is_encrypted ? 'encrypted' : ''}" 
                 data-note-id="${note.id}" 
                 style="background-color: ${note.color || '#ffffff'};">
                <div class="note-header">
                    <h3 class="note-title">${this.escapeHtml(note.title)}</h3>
                    <div class="note-actions">
                        ${note.is_encrypted ? '<i class="fas fa-lock" title="Encrypted"></i>' : ''}
                        <button onclick="notesManager.deleteNote(${note.id})" title="Delete Note">
                            <i class="fas fa-trash"></i>
                        </button>
                        <button onclick="notesManager.duplicateNote(${note.id})" title="Duplicate Note">
                            <i class="fas fa-clone"></i>
                        </button>
                    </div>
                </div>
                <div class="note-content">${contentPreview}</div>
                <div class="note-footer">
                    <div class="note-tags">
                        ${tags.map(tag => `<span class="note-tag">${this.escapeHtml(tag)}</span>`).join('')}
                    </div>
                    <div class="note-date">${createdAt}</div>
                </div>
            </div>
        `;
    }

    createNewNote() {
        this.currentNote = {
            id: null,
            title: '',
            content: '',
            tags: '',
            color: '#ffffff',
            is_encrypted: false
        };
        this.openEditor();
    }

    editNote(noteId) {
        const note = this.notes.find(n => n.id === noteId);
        if (note) {
            this.currentNote = { ...note };
            this.currentNote.tags = note.tags || '';
            this.openEditor();
        }
    }

    openEditor() {
        this.isEditing = true;
        const modal = document.getElementById('note-editor-modal');
        
        // Populate editor with current note data
        document.getElementById('note-title').value = this.currentNote.title || '';
        document.getElementById('note-content').innerHTML = this.currentNote.content || '';
        document.getElementById('note-tags').value = this.currentNote.tags || '';
        document.getElementById('note-color').value = this.currentNote.color || '#ffffff';
        
        // Update encryption toggle
        this.updateEncryptionToggle();
        
        // Show modal
        modal.classList.remove('hidden');
        modal.classList.add('fade-in');
        
        // Focus on title if it's empty, otherwise focus on content
        if (!this.currentNote.title) {
            document.getElementById('note-title').focus();
        } else {
            document.getElementById('note-content').focus();
        }
        
        this.updateWordCount();
    }

    closeEditor() {
        this.isEditing = false;
        document.getElementById('note-editor-modal').classList.add('hidden');
        this.currentNote = null;
    }

    async saveCurrentNote() {
        if (!this.currentNote) return;

        const title = document.getElementById('note-title').value.trim();
        const content = document.getElementById('note-content').innerHTML.trim();
        const tags = document.getElementById('note-tags').value.trim();
        const color = document.getElementById('note-color').value;

        if (!title && !content) {
            showNotification('Please add a title or content', 'warning');
            return;
        }

        const noteData = {
            title: title || 'Untitled Note',
            content: content,
            tags: tags,
            color: color,
            isEncrypted: this.currentNote.is_encrypted
        };

        try {
            let response;
            if (this.currentNote.id) {
                // Update existing note
                response = await window.authManager.makeAuthenticatedRequest(
                    `${this.apiUrl}/notes/${this.currentNote.id}`, 
                    {
                        method: 'PUT',
                        body: JSON.stringify(noteData)
                    }
                );
            } else {
                // Create new note
                response = await window.authManager.makeAuthenticatedRequest(
                    `${this.apiUrl}/notes`, 
                    {
                        method: 'POST',
                        body: JSON.stringify(noteData)
                    }
                );
            }

            if (response.ok) {
                showNotification('Note saved successfully!', 'success');
                this.closeEditor();
                await this.loadNotes(); // Reload notes to get updated data
            } else {
                const error = await response.json();
                showNotification(error.error || 'Failed to save note', 'error');
            }
        } catch (error) {
            console.error('Save note error:', error);
            showNotification('Failed to save note', 'error');
        }
    }

    async deleteNote(noteId) {
        if (!confirm('Are you sure you want to delete this note?')) {
            return;
        }

        try {
            const response = await window.authManager.makeAuthenticatedRequest(
                `${this.apiUrl}/notes/${noteId}`, 
                { method: 'DELETE' }
            );

            if (response.ok) {
                showNotification('Note deleted successfully', 'success');
                await this.loadNotes();
            } else {
                showNotification('Failed to delete note', 'error');
            }
        } catch (error) {
            console.error('Delete note error:', error);
            showNotification('Failed to delete note', 'error');
        }
    }

    async duplicateNote(noteId) {
        const note = this.notes.find(n => n.id === noteId);
        if (!note) return;

        const duplicateData = {
            title: `${note.title} (Copy)`,
            content: note.content,
            tags: note.tags,
            color: note.color,
            isEncrypted: note.is_encrypted
        };

        try {
            const response = await window.authManager.makeAuthenticatedRequest(
                `${this.apiUrl}/notes`, 
                {
                    method: 'POST',
                    body: JSON.stringify(duplicateData)
                }
            );

            if (response.ok) {
                showNotification('Note duplicated successfully!', 'success');
                await this.loadNotes();
            } else {
                showNotification('Failed to duplicate note', 'error');
            }
        } catch (error) {
            console.error('Duplicate note error:', error);
            showNotification('Failed to duplicate note', 'error');
        }
    }

    handleSearch(query) {
        this.searchQuery = query.trim();
        this.renderNotes();
    }

    toggleEncryption() {
        if (this.currentNote) {
            this.currentNote.is_encrypted = !this.currentNote.is_encrypted;
            this.updateEncryptionToggle();
        }
    }

    updateEncryptionToggle() {
        const toggleBtn = document.getElementById('encrypt-toggle');
        const icon = toggleBtn?.querySelector('i');
        
        if (icon && this.currentNote) {
            if (this.currentNote.is_encrypted) {
                icon.className = 'fas fa-lock';
                toggleBtn.classList.add('encrypted');
                toggleBtn.title = 'Encryption enabled';
            } else {
                icon.className = 'fas fa-lock-open';
                toggleBtn.classList.remove('encrypted');
                toggleBtn.title = 'Click to encrypt note';
            }
        }
    }

    updateNoteColor(color) {
        if (this.currentNote) {
            this.currentNote.color = color;
        }
    }

    updateWordCount() {
        const title = document.getElementById('note-title')?.value || '';
        const content = document.getElementById('note-content')?.textContent || '';
        
        const charCount = (title + content).length;
        const wordCount = (title + ' ' + content).trim().split(/\s+/).filter(word => word.length > 0).length;
        
        const charCountElement = document.getElementById('char-count');
        const wordCountElement = document.getElementById('word-count');
        
        if (charCountElement) charCountElement.textContent = `${charCount} characters`;
        if (wordCountElement) wordCountElement.textContent = `${wordCount} words`;
    }

    showEncryptedNotes() {
        // Filter to show only encrypted notes
        this.selectedTags = [];
        this.searchQuery = '';
        
        // Update search input
        const searchInput = document.getElementById('searchNotes');
        if (searchInput) searchInput.value = '';
        
        // Filter and render
        const encryptedNotes = this.notes.filter(note => note.is_encrypted);
        this.renderFilteredNotes(encryptedNotes, 'Encrypted Notes');
    }

    renderFilteredNotes(notes, title) {
        const notesGrid = document.getElementById('notes-grid');
        const emptyState = document.getElementById('empty-state');
        
        if (!notesGrid) return;

        if (notes.length === 0) {
            notesGrid.style.display = 'none';
            emptyState?.classList.remove('hidden');
            const emptyTitle = emptyState?.querySelector('h3');
            if (emptyTitle) emptyTitle.textContent = `No ${title.toLowerCase()} found`;
        } else {
            notesGrid.style.display = 'grid';
            emptyState?.classList.add('hidden');
            
            notesGrid.innerHTML = notes.map(note => this.createNoteCard(note)).join('');
            
            // Add event listeners
            notes.forEach(note => {
                const noteCard = document.querySelector(`[data-note-id="${note.id}"]`);
                if (noteCard) {
                    noteCard.addEventListener('click', (e) => {
                        if (!e.target.closest('.note-actions')) {
                            this.editNote(note.id);
                        }
                    });
                }
            });
        }
    }

    updateTagsList() {
        const tagsList = document.getElementById('tags-list');
        if (!tagsList) return;

        // Collect all unique tags
        const allTags = new Set();
        this.notes.forEach(note => {
            if (note.tags) {
                note.tags.split(',').forEach(tag => {
                    const trimmedTag = tag.trim();
                    if (trimmedTag) allTags.add(trimmedTag);
                });
            }
        });

        // Create tag elements
        tagsList.innerHTML = Array.from(allTags).map(tag => 
            `<div class="tag-item" onclick="notesManager.filterByTag('${tag}')">${this.escapeHtml(tag)}</div>`
        ).join('');
    }

    filterByTag(tag) {
        this.selectedTags = [tag];
        this.searchQuery = '';
        
        // Update search input
        const searchInput = document.getElementById('searchNotes');
        if (searchInput) searchInput.value = '';
        
        this.renderNotes();
    }

    // Utility functions
    stripHtml(html) {
        const tmp = document.createElement('div');
        tmp.innerHTML = html;
        return tmp.textContent || tmp.innerText || '';
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Text formatting functions for the editor
function formatText(command) {
    document.execCommand(command, false, null);
    document.getElementById('note-content').focus();
}

// Global function for creating new note (called from empty state)
function createNewNote() {
    if (window.notesManager) {
        window.notesManager.createNewNote();
    }
}

// Initialize notes manager
window.notesManager = new NotesManager();